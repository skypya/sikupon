/*
  # Complete Database Schema for Pondok Pesantren Management System

  1. New Tables
    - `users` - User authentication and profile data
    - `santris` - Complete student data with all fields
    - `transaksis` - Financial transactions (income/expense)
    - `tagihan_bulanan` - Monthly billing for students
    - `pembayarans` - Payment history records
    - `settings` - Application settings
    - `notifications` - System notifications

  2. Security
    - Enable RLS on all tables
    - Add comprehensive policies for authenticated users
    - Add admin-only policies where needed

  3. Performance
    - Add indexes for frequently queried columns
    - Add composite indexes for complex queries

  4. Data Integrity
    - Add foreign key constraints
    - Add check constraints for data validation
    - Add triggers for automatic updates
*/

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. USERS TABLE (Authentication & Profile)
CREATE TABLE IF NOT EXISTS users (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name varchar(100) NOT NULL,
    email varchar(100) UNIQUE NOT NULL,
    password_hash varchar(255),
    role varchar(20) DEFAULT 'admin' CHECK (role IN ('admin', 'staff')),
    phone varchar(20),
    address text,
    join_date date DEFAULT CURRENT_DATE,
    avatar_url text,
    is_active boolean DEFAULT true,
    last_login timestamptz,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- 2. SANTRIS TABLE (Complete Student Data)
CREATE TABLE IF NOT EXISTS santris (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Data Pribadi
    nama varchar(100) NOT NULL,
    tempat_lahir varchar(50),
    tanggal_lahir date NOT NULL,
    jenis_kelamin varchar(10) CHECK (jenis_kelamin IN ('Laki-laki', 'Perempuan')),
    alamat text NOT NULL,
    no_ktp varchar(20),
    no_kk varchar(20),
    golongan_darah varchar(5) CHECK (golongan_darah IN ('A', 'B', 'AB', 'O')),
    
    -- Data Wali/Orang Tua
    nama_wali varchar(100) NOT NULL,
    pekerjaan_wali varchar(50),
    kontak_wali varchar(20) NOT NULL,
    email_wali varchar(100),
    alamat_wali text,
    
    -- Data Pendidikan
    asal_sekolah varchar(100),
    tahun_lulus varchar(4),
    nilai_un varchar(10),
    
    -- Data Kesehatan
    riwayat_penyakit text,
    alergi text,
    
    -- Data Pondok
    tanggal_masuk date NOT NULL,
    kamar varchar(20),
    tingkat varchar(20) CHECK (tingkat IN ('Ibtidaiyah', 'Tsanawiyah', 'Aliyah', 'Tahfidz')),
    status varchar(20) DEFAULT 'aktif' CHECK (status IN ('aktif', 'nonaktif', 'lulus', 'pindah')),
    
    -- Data Tambahan
    hobi text,
    cita_cita text,
    motivasi text,
    foto text,
    
    -- Metadata
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    created_by uuid REFERENCES users(id)
);

-- 3. TRANSAKSIS TABLE (Financial Transactions)
CREATE TABLE IF NOT EXISTS transaksis (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    santri_id uuid REFERENCES santris(id) ON DELETE SET NULL,
    tanggal date NOT NULL,
    jumlah integer NOT NULL CHECK (jumlah > 0),
    jenis varchar(20) NOT NULL CHECK (jenis IN ('pemasukan', 'pengeluaran')),
    kategori varchar(50) NOT NULL,
    keterangan text NOT NULL,
    ttd varchar(100) NOT NULL,
    bukti_transaksi text, -- URL to receipt/proof
    metode_pembayaran varchar(20) DEFAULT 'tunai' CHECK (metode_pembayaran IN ('tunai', 'transfer', 'qris')),
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    created_by uuid REFERENCES users(id)
);

-- 4. TAGIHAN_BULANAN TABLE (Monthly Billing)
CREATE TABLE IF NOT EXISTS tagihan_bulanan (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    santri_id uuid NOT NULL REFERENCES santris(id) ON DELETE CASCADE,
    bulan integer NOT NULL CHECK (bulan BETWEEN 1 AND 12),
    tahun integer NOT NULL CHECK (tahun >= 2020 AND tahun <= 2030),
    
    -- Jumlah Tagihan
    jumlah_kas integer DEFAULT 10000 CHECK (jumlah_kas >= 0),
    jumlah_syahriyah integer DEFAULT 50000 CHECK (jumlah_syahriyah >= 0),
    
    -- Tanggal Penting
    tanggal_jatuh_tempo date NOT NULL,
    
    -- Status Pembayaran
    status_kas varchar(20) DEFAULT 'belum_lunas' CHECK (status_kas IN ('lunas', 'belum_lunas', 'terlambat')),
    status_syahriyah varchar(20) DEFAULT 'belum_lunas' CHECK (status_syahriyah IN ('lunas', 'belum_lunas', 'terlambat')),
    
    -- Tanggal Pembayaran
    tanggal_bayar_kas date,
    tanggal_bayar_syahriyah date,
    
    -- Denda
    denda_kas integer DEFAULT 0 CHECK (denda_kas >= 0),
    denda_syahriyah integer DEFAULT 0 CHECK (denda_syahriyah >= 0),
    total_denda integer DEFAULT 0 CHECK (total_denda >= 0),
    
    -- TTD Pembayaran
    ttd_kas varchar(100),
    ttd_syahriyah varchar(100),
    
    -- Metadata
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    
    UNIQUE(santri_id, bulan, tahun)
);

-- 5. PEMBAYARANS TABLE (Payment History)
CREATE TABLE IF NOT EXISTS pembayarans (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    santri_id uuid NOT NULL REFERENCES santris(id) ON DELETE CASCADE,
    tagihan_id uuid REFERENCES tagihan_bulanan(id) ON DELETE SET NULL,
    bulan varchar(20) NOT NULL,
    tahun integer NOT NULL,
    jenis_kekurangan varchar(20) CHECK (jenis_kekurangan IN ('kas', 'syahriyah')),
    jumlah integer NOT NULL CHECK (jumlah > 0),
    status varchar(20) DEFAULT 'lunas' CHECK (status IN ('lunas', 'pending', 'gagal')),
    tanggal_bayar date DEFAULT CURRENT_DATE,
    tanggal_jatuh_tempo date NOT NULL,
    denda integer DEFAULT 0 CHECK (denda >= 0),
    ttd varchar(100) NOT NULL,
    metode_pembayaran varchar(20) DEFAULT 'tunai',
    bukti_pembayaran text,
    catatan text,
    created_at timestamptz DEFAULT now(),
    created_by uuid REFERENCES users(id)
);

-- 6. SETTINGS TABLE (Application Settings)
CREATE TABLE IF NOT EXISTS settings (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    key varchar(50) UNIQUE NOT NULL,
    value text,
    description text,
    category varchar(30) DEFAULT 'general',
    is_public boolean DEFAULT false,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- 7. NOTIFICATIONS TABLE (System Notifications)
CREATE TABLE IF NOT EXISTS notifications (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES users(id) ON DELETE CASCADE,
    title varchar(200) NOT NULL,
    message text NOT NULL,
    type varchar(20) DEFAULT 'info' CHECK (type IN ('info', 'warning', 'error', 'success')),
    is_read boolean DEFAULT false,
    action_url text,
    expires_at timestamptz,
    created_at timestamptz DEFAULT now()
);

-- 8. AUDIT_LOGS TABLE (Activity Logging)
CREATE TABLE IF NOT EXISTS audit_logs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES users(id) ON DELETE SET NULL,
    table_name varchar(50) NOT NULL,
    record_id uuid,
    action varchar(20) NOT NULL CHECK (action IN ('INSERT', 'UPDATE', 'DELETE')),
    old_values jsonb,
    new_values jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamptz DEFAULT now()
);

-- INDEXES FOR PERFORMANCE
-- Users indexes
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_is_active ON users(is_active);

-- Santris indexes
CREATE INDEX IF NOT EXISTS idx_santris_nama ON santris(nama);
CREATE INDEX IF NOT EXISTS idx_santris_status ON santris(status);
CREATE INDEX IF NOT EXISTS idx_santris_tanggal_masuk ON santris(tanggal_masuk);
CREATE INDEX IF NOT EXISTS idx_santris_tingkat ON santris(tingkat);
CREATE INDEX IF NOT EXISTS idx_santris_kamar ON santris(kamar);

-- Transaksis indexes
CREATE INDEX IF NOT EXISTS idx_transaksis_tanggal ON transaksis(tanggal);
CREATE INDEX IF NOT EXISTS idx_transaksis_jenis ON transaksis(jenis);
CREATE INDEX IF NOT EXISTS idx_transaksis_kategori ON transaksis(kategori);
CREATE INDEX IF NOT EXISTS idx_transaksis_santri_id ON transaksis(santri_id);
CREATE INDEX IF NOT EXISTS idx_transaksis_created_at ON transaksis(created_at);

-- Tagihan indexes
CREATE INDEX IF NOT EXISTS idx_tagihan_santri_bulan_tahun ON tagihan_bulanan(santri_id, bulan, tahun);
CREATE INDEX IF NOT EXISTS idx_tagihan_status_kas ON tagihan_bulanan(status_kas);
CREATE INDEX IF NOT EXISTS idx_tagihan_status_syahriyah ON tagihan_bulanan(status_syahriyah);
CREATE INDEX IF NOT EXISTS idx_tagihan_jatuh_tempo ON tagihan_bulanan(tanggal_jatuh_tempo);
CREATE INDEX IF NOT EXISTS idx_tagihan_tahun_bulan ON tagihan_bulanan(tahun, bulan);

-- Pembayarans indexes
CREATE INDEX IF NOT EXISTS idx_pembayarans_santri_id ON pembayarans(santri_id);
CREATE INDEX IF NOT EXISTS idx_pembayarans_tanggal_bayar ON pembayarans(tanggal_bayar);
CREATE INDEX IF NOT EXISTS idx_pembayarans_status ON pembayarans(status);

-- Notifications indexes
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at);

-- Audit logs indexes
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_table_name ON audit_logs(table_name);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at);

-- FUNCTIONS AND TRIGGERS
-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply update_updated_at trigger to relevant tables
CREATE TRIGGER update_users_updated_at 
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_santris_updated_at 
    BEFORE UPDATE ON santris
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_transaksis_updated_at 
    BEFORE UPDATE ON transaksis
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tagihan_updated_at 
    BEFORE UPDATE ON tagihan_bulanan
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_settings_updated_at 
    BEFORE UPDATE ON settings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to automatically create monthly bills for new students
CREATE OR REPLACE FUNCTION create_monthly_bills_for_new_student()
RETURNS TRIGGER AS $$
DECLARE
    current_month integer;
    current_year integer;
    entry_month integer;
    entry_year integer;
    bill_month integer;
    bill_year integer;
BEGIN
    -- Get current date components
    current_month := EXTRACT(MONTH FROM CURRENT_DATE);
    current_year := EXTRACT(YEAR FROM CURRENT_DATE);
    
    -- Get entry date components
    entry_month := EXTRACT(MONTH FROM NEW.tanggal_masuk);
    entry_year := EXTRACT(YEAR FROM NEW.tanggal_masuk);
    
    -- Only create bills if student is active and entry date is not in the future
    IF NEW.status = 'aktif' AND NEW.tanggal_masuk <= CURRENT_DATE THEN
        bill_month := entry_month;
        bill_year := entry_year;
        
        -- Create bills from entry month to current month
        WHILE (bill_year < current_year) OR (bill_year = current_year AND bill_month <= current_month) LOOP
            INSERT INTO tagihan_bulanan (
                santri_id,
                bulan,
                tahun,
                tanggal_jatuh_tempo,
                jumlah_kas,
                jumlah_syahriyah
            ) VALUES (
                NEW.id,
                bill_month,
                bill_year,
                DATE(bill_year || '-' || bill_month || '-10'),
                10000,
                50000
            ) ON CONFLICT (santri_id, bulan, tahun) DO NOTHING;
            
            -- Move to next month
            bill_month := bill_month + 1;
            IF bill_month > 12 THEN
                bill_month := 1;
                bill_year := bill_year + 1;
            END IF;
        END LOOP;
    END IF;
    
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger to create bills for new students
CREATE TRIGGER create_bills_for_new_student
    AFTER INSERT ON santris
    FOR EACH ROW EXECUTE FUNCTION create_monthly_bills_for_new_student();

-- Function to log audit trail
CREATE OR REPLACE FUNCTION log_audit_trail()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        INSERT INTO audit_logs (table_name, record_id, action, old_values)
        VALUES (TG_TABLE_NAME, OLD.id, TG_OP, row_to_json(OLD));
        RETURN OLD;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_logs (table_name, record_id, action, old_values, new_values)
        VALUES (TG_TABLE_NAME, NEW.id, TG_OP, row_to_json(OLD), row_to_json(NEW));
        RETURN NEW;
    ELSIF TG_OP = 'INSERT' THEN
        INSERT INTO audit_logs (table_name, record_id, action, new_values)
        VALUES (TG_TABLE_NAME, NEW.id, TG_OP, row_to_json(NEW));
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ language 'plpgsql';

-- Apply audit triggers to important tables
CREATE TRIGGER audit_santris
    AFTER INSERT OR UPDATE OR DELETE ON santris
    FOR EACH ROW EXECUTE FUNCTION log_audit_trail();

CREATE TRIGGER audit_transaksis
    AFTER INSERT OR UPDATE OR DELETE ON transaksis
    FOR EACH ROW EXECUTE FUNCTION log_audit_trail();

CREATE TRIGGER audit_pembayarans
    AFTER INSERT OR UPDATE OR DELETE ON pembayarans
    FOR EACH ROW EXECUTE FUNCTION log_audit_trail();

-- INSERT DEFAULT SETTINGS
INSERT INTO settings (key, value, description, category, is_public) VALUES
('app_name', 'Sistem Manajemen Keuangan Pondok Pesantren', 'Application name', 'general', true),
('institution_name', 'Pondok Pesantren Al-Hikmah', 'Institution name', 'institution', true),
('institution_address', 'Jl. Raya Pesantren No. 123, Bandung, Jawa Barat', 'Institution address', 'institution', true),
('institution_phone', '022-1234567', 'Institution phone', 'institution', true),
('institution_email', 'contact@alhikmah.sch.id', 'Institution email', 'institution', true),
('kas_monthly_fee', '10000', 'Monthly kas fee in IDR', 'billing', false),
('syahriyah_monthly_fee', '50000', 'Monthly syahriyah fee in IDR', 'billing', false),
('late_payment_penalty', '0', 'Late payment penalty percentage', 'billing', false),
('bill_due_date', '10', 'Monthly bill due date', 'billing', false),
('academic_year_start', '7', 'Academic year start month (1-12)', 'academic', false),
('timezone', 'Asia/Jakarta', 'Application timezone', 'general', false)
ON CONFLICT (key) DO NOTHING;

-- ENABLE ROW LEVEL SECURITY
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE santris ENABLE ROW LEVEL SECURITY;
ALTER TABLE transaksis ENABLE ROW LEVEL SECURITY;
ALTER TABLE tagihan_bulanan ENABLE ROW LEVEL SECURITY;
ALTER TABLE pembayarans ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- RLS POLICIES
-- Users policies
CREATE POLICY "Users can read own data" ON users
    FOR SELECT TO authenticated
    USING (auth.uid() = id);

CREATE POLICY "Users can update own data" ON users
    FOR UPDATE TO authenticated
    USING (auth.uid() = id);

-- Santris policies
CREATE POLICY "Authenticated users can read santris" ON santris
    FOR SELECT TO authenticated
    USING (true);

CREATE POLICY "Authenticated users can insert santris" ON santris
    FOR INSERT TO authenticated
    WITH CHECK (true);

CREATE POLICY "Authenticated users can update santris" ON santris
    FOR UPDATE TO authenticated
    USING (true);

CREATE POLICY "Authenticated users can delete santris" ON santris
    FOR DELETE TO authenticated
    USING (true);

-- Transaksis policies
CREATE POLICY "Authenticated users can manage transaksis" ON transaksis
    FOR ALL TO authenticated
    USING (true);

-- Tagihan bulanan policies
CREATE POLICY "Authenticated users can manage tagihan" ON tagihan_bulanan
    FOR ALL TO authenticated
    USING (true);

-- Pembayarans policies
CREATE POLICY "Authenticated users can manage pembayarans" ON pembayarans
    FOR ALL TO authenticated
    USING (true);

-- Settings policies
CREATE POLICY "Authenticated users can read settings" ON settings
    FOR SELECT TO authenticated
    USING (true);

CREATE POLICY "Authenticated users can update settings" ON settings
    FOR UPDATE TO authenticated
    USING (true);

-- Notifications policies
CREATE POLICY "Users can read own notifications" ON notifications
    FOR SELECT TO authenticated
    USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notifications" ON notifications
    FOR UPDATE TO authenticated
    USING (auth.uid() = user_id);

-- Audit logs policies (read-only for authenticated users)
CREATE POLICY "Authenticated users can read audit logs" ON audit_logs
    FOR SELECT TO authenticated
    USING (true);