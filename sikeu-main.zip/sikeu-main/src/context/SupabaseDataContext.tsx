import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { Santri, Transaksi, TagihanBulanan } from '../types';

interface SupabaseDataContextType {
  santris: Santri[];
  transaksis: Transaksi[];
  tagihanBulanan: TagihanBulanan[];
  loading: boolean;
  error: string | null;
  
  // Santri operations
  addSantri: (santri: Omit<Santri, 'id'>) => Promise<void>;
  updateSantri: (id: string, santri: Partial<Santri>) => Promise<void>;
  deleteSantri: (id: string) => Promise<void>;
  
  // Transaksi operations
  addTransaksi: (transaksi: Omit<Transaksi, 'id' | 'createdAt'>) => Promise<void>;
  updateTransaksi: (id: string, transaksi: Partial<Transaksi>) => Promise<void>;
  deleteTransaksi: (id: string) => Promise<void>;
  
  // Tagihan operations
  generateTagihanBulanan: () => Promise<void>;
  bayarTagihan: (santriId: string, bulan: number, tahun: number, jenis: 'kas' | 'syahriyah', ttd: string) => Promise<void>;
  getTagihanSantri: (santriId: string) => TagihanBulanan[];
  getTotalTunggakan: () => { total: number; jumlahSantri: number };
  
  // Utility
  refreshData: () => Promise<void>;
}

const SupabaseDataContext = createContext<SupabaseDataContextType | undefined>(undefined);

export const useSupabaseData = () => {
  const context = useContext(SupabaseDataContext);
  if (context === undefined) {
    throw new Error('useSupabaseData must be used within a SupabaseDataProvider');
  }
  return context;
};

interface SupabaseDataProviderProps {
  children: ReactNode;
}

export const SupabaseDataProvider: React.FC<SupabaseDataProviderProps> = ({ children }) => {
  const [santris, setSantris] = useState<Santri[]>([]);
  const [transaksis, setTransaksis] = useState<Transaksi[]>([]);
  const [tagihanBulanan, setTagihanBulanan] = useState<TagihanBulanan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const BIAYA_KAS_BULANAN = 10000;
  const BIAYA_SYAHRIYAH_BULANAN = 50000;

  // Load initial data
  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Load santris
      const { data: santrisData, error: santrisError } = await supabase
        .from('santris')
        .select('*')
        .order('created_at', { ascending: false });

      if (santrisError) throw santrisError;

      // Load transaksis
      const { data: transaksiData, error: transaksiError } = await supabase
        .from('transaksis')
        .select('*')
        .order('created_at', { ascending: false });

      if (transaksiError) throw transaksiError;

      // Load tagihan bulanan
      const { data: tagihanData, error: tagihanError } = await supabase
        .from('tagihan_bulanan')
        .select('*')
        .order('tahun', { ascending: false })
        .order('bulan', { ascending: false });

      if (tagihanError) throw tagihanError;

      // Transform data to match frontend types
      const transformedSantris: Santri[] = santrisData?.map(s => ({
        id: s.id,
        nama: s.nama,
        tempatLahir: s.tempat_lahir || '',
        tanggalLahir: s.tanggal_lahir,
        jenisKelamin: s.jenis_kelamin || '',
        alamat: s.alamat,
        noKTP: s.no_ktp || '',
        noKK: s.no_kk || '',
        golonganDarah: s.golongan_darah || '',
        namaWali: s.nama_wali,
        pekerjaanWali: s.pekerjaan_wali || '',
        kontakWali: s.kontak_wali,
        emailWali: s.email_wali || '',
        alamatWali: s.alamat_wali || '',
        asalSekolah: s.asal_sekolah || '',
        tahunLulus: s.tahun_lulus || '',
        nilaiUN: s.nilai_un || '',
        riwayatPenyakit: s.riwayat_penyakit || '',
        alergi: s.alergi || '',
        tanggalMasuk: s.tanggal_masuk,
        kamar: s.kamar || '',
        tingkat: s.tingkat || '',
        status: s.status as 'aktif' | 'nonaktif',
        hobi: s.hobi || '',
        cita_cita: s.cita_cita || '',
        motivasi: s.motivasi || '',
        foto: s.foto || '',
      })) || [];

      const transformedTransaksis: Transaksi[] = transaksiData?.map(t => ({
        id: t.id,
        santriId: t.santri_id || undefined,
        tanggal: t.tanggal,
        jumlah: t.jumlah,
        jenis: t.jenis as 'pemasukan' | 'pengeluaran',
        kategori: t.kategori,
        keterangan: t.keterangan,
        ttd: t.ttd,
        createdAt: t.created_at,
      })) || [];

      const transformedTagihan: TagihanBulanan[] = tagihanData?.map(t => ({
        id: t.id,
        santriId: t.santri_id,
        bulan: t.bulan,
        tahun: t.tahun,
        jumlahKas: t.jumlah_kas,
        jumlahSyahriyah: t.jumlah_syahriyah,
        tanggalJatuhTempo: t.tanggal_jatuh_tempo,
        statusKas: t.status_kas as 'lunas' | 'belum_lunas' | 'terlambat',
        statusSyahriyah: t.status_syahriyah as 'lunas' | 'belum_lunas' | 'terlambat',
        tanggalBayarKas: t.tanggal_bayar_kas || undefined,
        tanggalBayarSyahriyah: t.tanggal_bayar_syahriyah || undefined,
        dendaKas: t.denda_kas,
        dendaSyahriyah: t.denda_syahriyah,
        totalDenda: t.total_denda,
        ttdKas: t.ttd_kas || undefined,
        ttdSyahriyah: t.ttd_syahriyah || undefined,
      })) || [];

      setSantris(transformedSantris);
      setTransaksis(transformedTransaksis);
      setTagihanBulanan(transformedTagihan);

    } catch (err) {
      console.error('Error loading data:', err);
      setError(err instanceof Error ? err.message : 'Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  // Santri operations
  const addSantri = async (santri: Omit<Santri, 'id'>) => {
    try {
      const { data, error } = await supabase
        .from('santris')
        .insert({
          nama: santri.nama,
          tempat_lahir: santri.tempatLahir,
          tanggal_lahir: santri.tanggalLahir,
          jenis_kelamin: santri.jenisKelamin,
          alamat: santri.alamat,
          no_ktp: santri.noKTP,
          no_kk: santri.noKK,
          golongan_darah: santri.golonganDarah,
          nama_wali: santri.namaWali,
          pekerjaan_wali: santri.pekerjaanWali,
          kontak_wali: santri.kontakWali,
          email_wali: santri.emailWali,
          alamat_wali: santri.alamatWali,
          asal_sekolah: santri.asalSekolah,
          tahun_lulus: santri.tahunLulus,
          nilai_un: santri.nilaiUN,
          riwayat_penyakit: santri.riwayatPenyakit,
          alergi: santri.alergi,
          tanggal_masuk: santri.tanggalMasuk,
          kamar: santri.kamar,
          tingkat: santri.tingkat,
          status: santri.status,
          hobi: santri.hobi,
          cita_cita: santri.cita_cita,
          motivasi: santri.motivasi,
          foto: santri.foto,
        })
        .select()
        .single();

      if (error) throw error;

      await refreshData();
      await generateTagihanBulanan();
    } catch (err) {
      console.error('Error adding santri:', err);
      throw err;
    }
  };

  const updateSantri = async (id: string, santri: Partial<Santri>) => {
    try {
      const updateData: any = {};
      
      if (santri.nama !== undefined) updateData.nama = santri.nama;
      if (santri.tempatLahir !== undefined) updateData.tempat_lahir = santri.tempatLahir;
      if (santri.tanggalLahir !== undefined) updateData.tanggal_lahir = santri.tanggalLahir;
      if (santri.jenisKelamin !== undefined) updateData.jenis_kelamin = santri.jenisKelamin;
      if (santri.alamat !== undefined) updateData.alamat = santri.alamat;
      if (santri.noKTP !== undefined) updateData.no_ktp = santri.noKTP;
      if (santri.noKK !== undefined) updateData.no_kk = santri.noKK;
      if (santri.golonganDarah !== undefined) updateData.golongan_darah = santri.golonganDarah;
      if (santri.namaWali !== undefined) updateData.nama_wali = santri.namaWali;
      if (santri.pekerjaanWali !== undefined) updateData.pekerjaan_wali = santri.pekerjaanWali;
      if (santri.kontakWali !== undefined) updateData.kontak_wali = santri.kontakWali;
      if (santri.emailWali !== undefined) updateData.email_wali = santri.emailWali;
      if (santri.alamatWali !== undefined) updateData.alamat_wali = santri.alamatWali;
      if (santri.asalSekolah !== undefined) updateData.asal_sekolah = santri.asalSekolah;
      if (santri.tahunLulus !== undefined) updateData.tahun_lulus = santri.tahunLulus;
      if (santri.nilaiUN !== undefined) updateData.nilai_un = santri.nilaiUN;
      if (santri.riwayatPenyakit !== undefined) updateData.riwayat_penyakit = santri.riwayatPenyakit;
      if (santri.alergi !== undefined) updateData.alergi = santri.alergi;
      if (santri.tanggalMasuk !== undefined) updateData.tanggal_masuk = santri.tanggalMasuk;
      if (santri.kamar !== undefined) updateData.kamar = santri.kamar;
      if (santri.tingkat !== undefined) updateData.tingkat = santri.tingkat;
      if (santri.status !== undefined) updateData.status = santri.status;
      if (santri.hobi !== undefined) updateData.hobi = santri.hobi;
      if (santri.cita_cita !== undefined) updateData.cita_cita = santri.cita_cita;
      if (santri.motivasi !== undefined) updateData.motivasi = santri.motivasi;
      if (santri.foto !== undefined) updateData.foto = santri.foto;

      const { error } = await supabase
        .from('santris')
        .update(updateData)
        .eq('id', id);

      if (error) throw error;

      await refreshData();
      
      // If tanggal_masuk changed, regenerate tagihan
      if (santri.tanggalMasuk) {
        await generateTagihanBulanan();
      }
    } catch (err) {
      console.error('Error updating santri:', err);
      throw err;
    }
  };

  const deleteSantri = async (id: string) => {
    try {
      const { error } = await supabase
        .from('santris')
        .delete()
        .eq('id', id);

      if (error) throw error;

      await refreshData();
    } catch (err) {
      console.error('Error deleting santri:', err);
      throw err;
    }
  };

  // Transaksi operations
  const addTransaksi = async (transaksi: Omit<Transaksi, 'id' | 'createdAt'>) => {
    try {
      const { error } = await supabase
        .from('transaksis')
        .insert({
          santri_id: transaksi.santriId,
          tanggal: transaksi.tanggal,
          jumlah: transaksi.jumlah,
          jenis: transaksi.jenis,
          kategori: transaksi.kategori,
          keterangan: transaksi.keterangan,
          ttd: transaksi.ttd,
        });

      if (error) throw error;

      await refreshData();
    } catch (err) {
      console.error('Error adding transaksi:', err);
      throw err;
    }
  };

  const updateTransaksi = async (id: string, transaksi: Partial<Transaksi>) => {
    try {
      const updateData: any = {};
      
      if (transaksi.santriId !== undefined) updateData.santri_id = transaksi.santriId;
      if (transaksi.tanggal !== undefined) updateData.tanggal = transaksi.tanggal;
      if (transaksi.jumlah !== undefined) updateData.jumlah = transaksi.jumlah;
      if (transaksi.jenis !== undefined) updateData.jenis = transaksi.jenis;
      if (transaksi.kategori !== undefined) updateData.kategori = transaksi.kategori;
      if (transaksi.keterangan !== undefined) updateData.keterangan = transaksi.keterangan;
      if (transaksi.ttd !== undefined) updateData.ttd = transaksi.ttd;

      const { error } = await supabase
        .from('transaksis')
        .update(updateData)
        .eq('id', id);

      if (error) throw error;

      await refreshData();
    } catch (err) {
      console.error('Error updating transaksi:', err);
      throw err;
    }
  };

  const deleteTransaksi = async (id: string) => {
    try {
      const { error } = await supabase
        .from('transaksis')
        .delete()
        .eq('id', id);

      if (error) throw error;

      await refreshData();
    } catch (err) {
      console.error('Error deleting transaksi:', err);
      throw err;
    }
  };

  // Tagihan operations
  const generateTagihanBulanan = async () => {
    try {
      const currentDate = new Date();
      const currentMonth = currentDate.getMonth() + 1;
      const currentYear = currentDate.getFullYear();

      const activeSantris = santris.filter(s => s.status === 'aktif');

      for (const santri of activeSantris) {
        const tanggalMasuk = new Date(santri.tanggalMasuk);
        const masukMonth = tanggalMasuk.getMonth() + 1;
        const masukYear = tanggalMasuk.getFullYear();

        if (tanggalMasuk > currentDate) continue;

        let targetYear = masukYear;
        let targetMonth = masukMonth;

        while (targetYear < currentYear || (targetYear === currentYear && targetMonth <= currentMonth)) {
          // Check if tagihan already exists
          const existingTagihan = tagihanBulanan.find(
            t => t.santriId === santri.id && t.bulan === targetMonth && t.tahun === targetYear
          );

          if (!existingTagihan) {
            const tanggalJatuhTempo = new Date(targetYear, targetMonth - 1, 10);
            const isOverdue = currentDate > tanggalJatuhTempo;

            const { error } = await supabase
              .from('tagihan_bulanan')
              .insert({
                santri_id: santri.id,
                bulan: targetMonth,
                tahun: targetYear,
                jumlah_kas: BIAYA_KAS_BULANAN,
                jumlah_syahriyah: BIAYA_SYAHRIYAH_BULANAN,
                tanggal_jatuh_tempo: tanggalJatuhTempo.toISOString().split('T')[0],
                status_kas: isOverdue ? 'terlambat' : 'belum_lunas',
                status_syahriyah: isOverdue ? 'terlambat' : 'belum_lunas',
                denda_kas: 0,
                denda_syahriyah: 0,
                total_denda: 0,
              });

            if (error) throw error;
          }

          targetMonth++;
          if (targetMonth > 12) {
            targetMonth = 1;
            targetYear++;
          }
        }
      }

      await refreshData();
    } catch (err) {
      console.error('Error generating tagihan:', err);
      throw err;
    }
  };

  const bayarTagihan = async (santriId: string, bulan: number, tahun: number, jenis: 'kas' | 'syahriyah', ttd: string) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const updateData: any = {};

      if (jenis === 'kas') {
        updateData.status_kas = 'lunas';
        updateData.tanggal_bayar_kas = today;
        updateData.ttd_kas = ttd;
      } else {
        updateData.status_syahriyah = 'lunas';
        updateData.tanggal_bayar_syahriyah = today;
        updateData.ttd_syahriyah = ttd;
      }

      const { error } = await supabase
        .from('tagihan_bulanan')
        .update(updateData)
        .eq('santri_id', santriId)
        .eq('bulan', bulan)
        .eq('tahun', tahun);

      if (error) throw error;

      // Add transaction record
      const jumlah = jenis === 'kas' ? BIAYA_KAS_BULANAN : BIAYA_SYAHRIYAH_BULANAN;
      const monthNames = [
        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
      ];

      await addTransaksi({
        santriId,
        tanggal: today,
        jumlah: jumlah,
        jenis: 'pemasukan',
        kategori: jenis,
        keterangan: `Pembayaran ${jenis} ${monthNames[bulan - 1]} ${tahun}`,
        ttd: ttd,
      });

      await refreshData();
    } catch (err) {
      console.error('Error paying tagihan:', err);
      throw err;
    }
  };

  const getTagihanSantri = (santriId: string): TagihanBulanan[] => {
    return tagihanBulanan.filter(t => t.santriId === santriId);
  };

  const getTotalTunggakan = () => {
    const currentDate = new Date();
    let totalTunggakan = 0;
    const santriWithTunggakan = new Set<string>();

    const activeSantriIds = santris.filter(s => s.status === 'aktif').map(s => s.id);

    tagihanBulanan.forEach(tagihan => {
      if (!activeSantriIds.includes(tagihan.santriId)) return;

      const santri = santris.find(s => s.id === tagihan.santriId);
      if (!santri) return;

      const tanggalMasukSantri = new Date(santri.tanggalMasuk);
      const tanggalTagihan = new Date(tagihan.tahun, tagihan.bulan - 1, 1);
      
      if (tanggalTagihan < tanggalMasukSantri) return;

      const jatuhTempo = new Date(tagihan.tanggalJatuhTempo);
      
      if (currentDate > jatuhTempo) {
        if (tagihan.statusKas !== 'lunas') {
          totalTunggakan += tagihan.jumlahKas;
          santriWithTunggakan.add(tagihan.santriId);
        }
        
        if (tagihan.statusSyahriyah !== 'lunas') {
          totalTunggakan += tagihan.jumlahSyahriyah;
          santriWithTunggakan.add(tagihan.santriId);
        }
      }
    });

    return {
      total: totalTunggakan,
      jumlahSantri: santriWithTunggakan.size,
    };
  };

  const refreshData = async () => {
    await loadData();
  };

  // Load data on mount
  useEffect(() => {
    loadData();
  }, []);

  // Auto-generate tagihan when santris change
  useEffect(() => {
    if (santris.length > 0 && !loading) {
      const timer = setTimeout(() => {
        generateTagihanBulanan();
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [santris.length, loading]);

  return (
    <SupabaseDataContext.Provider value={{
      santris,
      transaksis,
      tagihanBulanan,
      loading,
      error,
      addSantri,
      updateSantri,
      deleteSantri,
      addTransaksi,
      updateTransaksi,
      deleteTransaksi,
      generateTagihanBulanan,
      bayarTagihan,
      getTagihanSantri,
      getTotalTunggakan,
      refreshData,
    }}>
      {children}
    </SupabaseDataContext.Provider>
  );
};