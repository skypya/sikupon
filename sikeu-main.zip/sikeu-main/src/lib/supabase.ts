import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
});

// Database types
export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          name: string;
          email: string;
          password_hash: string;
          role: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          email: string;
          password_hash: string;
          role?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          email?: string;
          password_hash?: string;
          role?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      santris: {
        Row: {
          id: string;
          nama: string;
          tempat_lahir: string | null;
          tanggal_lahir: string;
          jenis_kelamin: string | null;
          alamat: string;
          no_ktp: string | null;
          no_kk: string | null;
          golongan_darah: string | null;
          nama_wali: string;
          pekerjaan_wali: string | null;
          kontak_wali: string;
          email_wali: string | null;
          alamat_wali: string | null;
          asal_sekolah: string | null;
          tahun_lulus: string | null;
          nilai_un: string | null;
          riwayat_penyakit: string | null;
          alergi: string | null;
          tanggal_masuk: string;
          kamar: string | null;
          tingkat: string | null;
          status: string;
          hobi: string | null;
          cita_cita: string | null;
          motivasi: string | null;
          foto: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          nama: string;
          tempat_lahir?: string | null;
          tanggal_lahir: string;
          jenis_kelamin?: string | null;
          alamat: string;
          no_ktp?: string | null;
          no_kk?: string | null;
          golongan_darah?: string | null;
          nama_wali: string;
          pekerjaan_wali?: string | null;
          kontak_wali: string;
          email_wali?: string | null;
          alamat_wali?: string | null;
          asal_sekolah?: string | null;
          tahun_lulus?: string | null;
          nilai_un?: string | null;
          riwayat_penyakit?: string | null;
          alergi?: string | null;
          tanggal_masuk: string;
          kamar?: string | null;
          tingkat?: string | null;
          status?: string;
          hobi?: string | null;
          cita_cita?: string | null;
          motivasi?: string | null;
          foto?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          nama?: string;
          tempat_lahir?: string | null;
          tanggal_lahir?: string;
          jenis_kelamin?: string | null;
          alamat?: string;
          no_ktp?: string | null;
          no_kk?: string | null;
          golongan_darah?: string | null;
          nama_wali?: string;
          pekerjaan_wali?: string | null;
          kontak_wali?: string;
          email_wali?: string | null;
          alamat_wali?: string | null;
          asal_sekolah?: string | null;
          tahun_lulus?: string | null;
          nilai_un?: string | null;
          riwayat_penyakit?: string | null;
          alergi?: string | null;
          tanggal_masuk?: string;
          kamar?: string | null;
          tingkat?: string | null;
          status?: string;
          hobi?: string | null;
          cita_cita?: string | null;
          motivasi?: string | null;
          foto?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      transaksis: {
        Row: {
          id: string;
          santri_id: string | null;
          tanggal: string;
          jumlah: number;
          jenis: string;
          kategori: string;
          keterangan: string;
          ttd: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          santri_id?: string | null;
          tanggal: string;
          jumlah: number;
          jenis: string;
          kategori: string;
          keterangan: string;
          ttd: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          santri_id?: string | null;
          tanggal?: string;
          jumlah?: number;
          jenis?: string;
          kategori?: string;
          keterangan?: string;
          ttd?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      tagihan_bulanan: {
        Row: {
          id: string;
          santri_id: string;
          bulan: number;
          tahun: number;
          jumlah_kas: number;
          jumlah_syahriyah: number;
          tanggal_jatuh_tempo: string;
          status_kas: string;
          status_syahriyah: string;
          tanggal_bayar_kas: string | null;
          tanggal_bayar_syahriyah: string | null;
          denda_kas: number;
          denda_syahriyah: number;
          total_denda: number;
          ttd_kas: string | null;
          ttd_syahriyah: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          santri_id: string;
          bulan: number;
          tahun: number;
          jumlah_kas?: number;
          jumlah_syahriyah?: number;
          tanggal_jatuh_tempo: string;
          status_kas?: string;
          status_syahriyah?: string;
          tanggal_bayar_kas?: string | null;
          tanggal_bayar_syahriyah?: string | null;
          denda_kas?: number;
          denda_syahriyah?: number;
          total_denda?: number;
          ttd_kas?: string | null;
          ttd_syahriyah?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          santri_id?: string;
          bulan?: number;
          tahun?: number;
          jumlah_kas?: number;
          jumlah_syahriyah?: number;
          tanggal_jatuh_tempo?: string;
          status_kas?: string;
          status_syahriyah?: string;
          tanggal_bayar_kas?: string | null;
          tanggal_bayar_syahriyah?: string | null;
          denda_kas?: number;
          denda_syahriyah?: number;
          total_denda?: number;
          ttd_kas?: string | null;
          ttd_syahriyah?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
};