/*
  # Insert Sample Data for Development and Testing

  This migration adds sample data to help with development and testing.
  Remove or modify this for production use.
*/

-- Insert sample admin user (password will be handled by Supabase Auth)
INSERT INTO users (id, name, email, role, phone, address, join_date) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'Administrator', 'admin@pondok.com', 'admin', '08123456789', 'Jl. Admin No. 1, Bandung', '2023-01-01'),
('550e8400-e29b-41d4-a716-446655440001', 'Staff Keuangan', 'staff@pondok.com', 'staff', '08123456788', 'Jl. Staff No. 2, Bandung', '2023-06-01')
ON CONFLICT (id) DO NOTHING;

-- Insert sample santris with complete data
INSERT INTO santris (
    id, nama, tempat_lahir, tanggal_lahir, jenis_kelamin, alamat, no_ktp, no_kk, golongan_darah,
    nama_wali, pekerjaan_wali, kontak_wali, email_wali, alamat_wali,
    asal_sekolah, tahun_lulus, nilai_un,
    riwayat_penyakit, alergi,
    tanggal_masuk, kamar, tingkat, status,
    hobi, cita_cita, motivasi,
    created_by
) VALUES
(
    '660e8400-e29b-41d4-a716-446655440000',
    'Ahmad Fauzi bin Abdullah',
    'Bandung',
    '2005-03-15',
    'Laki-laki',
    'Jl. Merdeka No. 123, Bandung, Jawa Barat 40123',
    '3273051503050001',
    '3273050312050001',
    'A',
    'Abdullah bin Usman',
    'Pedagang',
    '08123456789',
    'abdullah.usman@email.com',
    'Jl. Merdeka No. 123, Bandung, Jawa Barat 40123',
    'SMP Negeri 1 Bandung',
    '2020',
    '85.5',
    'Tidak ada',
    'Tidak ada',
    '2024-01-01',
    'A-101',
    'Tsanawiyah',
    'aktif',
    'Membaca Al-Quran, Futsal',
    'Menjadi Ustadz',
    'Ingin mendalami ilmu agama dan menjadi hafidz Quran',
    '550e8400-e29b-41d4-a716-446655440000'
),
(
    '660e8400-e29b-41d4-a716-446655440001',
    'Muhammad Rizki bin Ahmad',
    'Jakarta',
    '2004-11-20',
    'Laki-laki',
    'Jl. Sudirman No. 45, Jakarta Pusat, DKI Jakarta 10110',
    '3171052011040001',
    '3171050812040001',
    'B',
    'Ahmad bin Sholeh',
    'Guru',
    '08987654321',
    'ahmad.sholeh@email.com',
    'Jl. Sudirman No. 45, Jakarta Pusat, DKI Jakarta 10110',
    'SMP Islam Al-Azhar Jakarta',
    '2019',
    '88.2',
    'Asma ringan',
    'Debu',
    '2023-07-01',
    'B-205',
    'Aliyah',
    'aktif',
    'Kaligrafi, Basket',
    'Menjadi Dai',
    'Ingin menyebarkan dakwah Islam ke seluruh dunia',
    '550e8400-e29b-41d4-a716-446655440000'
),
(
    '660e8400-e29b-41d4-a716-446655440002',
    'Ali Hasan bin Mahmud',
    'Surabaya',
    '2006-07-10',
    'Laki-laki',
    'Jl. Pemuda No. 78, Surabaya, Jawa Timur 60271',
    '3578071007060001',
    '3578070507060001',
    'O',
    'Mahmud bin Yusuf',
    'Wiraswasta',
    '08567891234',
    'mahmud.yusuf@email.com',
    'Jl. Pemuda No. 78, Surabaya, Jawa Timur 60271',
    'SMP Muhammadiyah Surabaya',
    '2021',
    '82.7',
    'Tidak ada',
    'Seafood',
    '2024-02-15',
    'C-301',
    'Ibtidaiyah',
    'aktif',
    'Tahfidz, Sepak Bola',
    'Menjadi Hafidz 30 Juz',
    'Ingin menghafal Al-Quran dan mengajarkannya',
    '550e8400-e29b-41d4-a716-446655440000'
),
(
    '660e8400-e29b-41d4-a716-446655440003',
    'Umar Faruq bin Khalid',
    'Yogyakarta',
    '2003-12-05',
    'Laki-laki',
    'Jl. Malioboro No. 156, Yogyakarta, DIY 55213',
    '3471050512030001',
    '3471051212030001',
    'AB',
    'Khalid bin Omar',
    'Dosen',
    '08345678912',
    'khalid.omar@email.com',
    'Jl. Malioboro No. 156, Yogyakarta, DIY 55213',
    'SMA Negeri 1 Yogyakarta',
    '2021',
    '91.3',
    'Migrain',
    'Tidak ada',
    '2023-08-01',
    'D-102',
    'Tahfidz',
    'aktif',
    'Debat, Menulis',
    'Menjadi Ulama',
    'Ingin menjadi ulama yang bermanfaat bagi umat',
    '550e8400-e29b-41d4-a716-446655440000'
),
(
    '660e8400-e29b-41d4-a716-446655440004',
    'Yusuf Ibrahim bin Ismail',
    'Medan',
    '2005-09-25',
    'Laki-laki',
    'Jl. Gatot Subroto No. 89, Medan, Sumatera Utara 20235',
    '1271052509050001',
    '1271050909050001',
    'A',
    'Ismail bin Ibrahim',
    'Pengusaha',
    '08234567891',
    'ismail.ibrahim@email.com',
    'Jl. Gatot Subroto No. 89, Medan, Sumatera Utara 20235',
    'SMP IT Al-Ittihad Medan',
    '2020',
    '86.8',
    'Tidak ada',
    'Kacang',
    '2024-03-01',
    'A-205',
    'Tsanawiyah',
    'aktif',
    'Panahan, Renang',
    'Menjadi Entrepreneur Muslim',
    'Ingin membangun bisnis yang berkah dan bermanfaat',
    '550e8400-e29b-41d4-a716-446655440000'
)
ON CONFLICT (id) DO NOTHING;

-- Insert sample transactions
INSERT INTO transaksis (
    id, santri_id, tanggal, jumlah, jenis, kategori, keterangan, ttd, metode_pembayaran, created_by
) VALUES
('770e8400-e29b-41d4-a716-446655440000', '660e8400-e29b-41d4-a716-446655440000', '2024-01-15', 50000, 'pemasukan', 'syahriyah', 'Pembayaran syahriyah bulan Januari 2024', 'Admin', 'tunai', '550e8400-e29b-41d4-a716-446655440000'),
('770e8400-e29b-41d4-a716-446655440001', '660e8400-e29b-41d4-a716-446655440000', '2024-01-15', 10000, 'pemasukan', 'kas', 'Pembayaran kas bulan Januari 2024', 'Admin', 'tunai', '550e8400-e29b-41d4-a716-446655440000'),
('770e8400-e29b-41d4-a716-446655440002', '660e8400-e29b-41d4-a716-446655440001', '2024-01-16', 50000, 'pemasukan', 'syahriyah', 'Pembayaran syahriyah bulan Januari 2024', 'Admin', 'transfer', '550e8400-e29b-41d4-a716-446655440000'),
('770e8400-e29b-41d4-a716-446655440003', NULL, '2024-01-16', 300000, 'pengeluaran', 'makan', 'Belanja keperluan dapur dan makan santri', 'Ustadz Ahmad', 'tunai', '550e8400-e29b-41d4-a716-446655440000'),
('770e8400-e29b-41d4-a716-446655440004', NULL, '2024-01-17', 150000, 'pengeluaran', 'operasional', 'Pembayaran listrik bulan Januari', 'Admin', 'transfer', '550e8400-e29b-41d4-a716-446655440000'),
('770e8400-e29b-41d4-a716-446655440005', NULL, '2024-01-18', 500000, 'pemasukan', 'donasi', 'Donasi dari alumni untuk pembangunan masjid', 'Ustadz Mahmud', 'transfer', '550e8400-e29b-41d4-a716-446655440000'),
('770e8400-e29b-41d4-a716-446655440006', '660e8400-e29b-41d4-a716-446655440002', '2024-02-20', 50000, 'pemasukan', 'syahriyah', 'Pembayaran syahriyah bulan Februari 2024', 'Staff', 'tunai', '550e8400-e29b-41d4-a716-446655440001'),
('770e8400-e29b-41d4-a716-446655440007', NULL, '2024-02-21', 200000, 'pengeluaran', 'sarpras', 'Pembelian buku-buku pelajaran', 'Ustadz Ali', 'tunai', '550e8400-e29b-41d4-a716-446655440000')
ON CONFLICT (id) DO NOTHING;

-- Sample notifications
INSERT INTO notifications (user_id, title, message, type, action_url) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'Selamat Datang!', 'Selamat datang di Sistem Manajemen Keuangan Pondok Pesantren', 'success', '/dashboard'),
('550e8400-e29b-41d4-a716-446655440000', 'Tunggakan Ditemukan', 'Terdapat beberapa santri dengan tunggakan pembayaran', 'warning', '/santri?filter=tunggakan'),
('550e8400-e29b-41d4-a716-446655440001', 'Akun Staff Aktif', 'Akun staff keuangan telah diaktifkan', 'info', '/profil')
ON CONFLICT DO NOTHING;